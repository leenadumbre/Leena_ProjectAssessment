import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginQA {

	  public static BufferedReader br;
	  public static FileReader fr;
	  public static File myFile;
	  public static File myFile1;
	  public static BufferedWriter output;
	  public static BufferedWriter output1;
	  public static  WebDriver driver;
	  public static  String email;
	  public static String passwd;




@BeforeClass
public static void URL() throws IOException
{
			Properties prop = new Properties();
		InputStream input = new FileInputStream("C:/QARetail/seleniumTest/src/Config.properties");
		prop.load(input);

		 email = prop.getProperty("email");
		 passwd = prop.getProperty("passwd");

		System.out.println(prop.getProperty("webdriver.chrome.driver"));

		ChromeOptions options = new ChromeOptions();
		options.addArguments("chrome.switches", "--disable-extensions");
		options.addArguments("start-maximized");
		options.addArguments("--enable-automation");

		System.setProperty("webdriver.chrome.driver", prop.getProperty("webdriver.chrome.driver"));

		driver = new ChromeDriver(options);

		driver.navigate().to(prop.getProperty("url"));
		System.out.println("Enter the URL..."+prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);


}


@Test(priority = 0)
public static void clickLogin()
{
	// Click on Sign In
	driver.findElement(By.className("login")).click();
	driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);

}


@Test(priority = 1)
public static void enterEmail()
{
		// Enter user name
		driver.findElement(By.id("email")).sendKeys(email);
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
}


@Test(priority = 2)
public static void enterPassword()
{
				// Enter password
		driver.findElement(By.id("passwd")).sendKeys(passwd);
}


@Test(priority = 3)
public static void clickSubmitButton()
{
				// Click Sign In Button
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		driver.findElement(By.id("SubmitLogin")).click();
}

@Test(priority = 4)
public static void searchButton()
{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);

		driver.findElement(By.id("search_query_top")).sendKeys("abcd");

		driver.findElement(By.name("submit_search")).click();


}
@AfterClass
public static void close()
{


		driver.close();
}
	}


